package co.edu.usbcali.stb.service;

import co.edu.usbcali.stb.dto.CuentaDTO;
import co.edu.usbcali.stb.mocks.CuentaMocksTest;
import co.edu.usbcali.stb.repository.CuentaRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.assertj.core.api.BDDAssumptions.given;

@SpringBootTest
public class CuentaServiceImplTest {
    @Mock
    private CuentaRepository cuentaRepository;
    @InjectMocks
    private CuentaServiceImplTest cuentaService;
@Test
    void pruebaCorrecta(){
        Assertions.assertEquals(1,1);
    }



}
