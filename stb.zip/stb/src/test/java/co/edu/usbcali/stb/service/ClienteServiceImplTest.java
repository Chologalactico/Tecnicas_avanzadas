package co.edu.usbcali.stb.service;

import co.edu.usbcali.stb.dto.ClienteDTO;
import co.edu.usbcali.stb.mocks.ClienteMocksTest;
import co.edu.usbcali.stb.repository.ClienteRepository;
import co.edu.usbcali.stb.service.impl.ClienteServiceimpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.BDDMockito.given;

@SpringBootTest
public class ClienteServiceImplTest {

    @Mock
    private ClienteRepository clienteRepository;
    @InjectMocks
    private ClienteServiceimpl clienteService;
    @Test
        void pruebaCorrecta(){
        Assertions.assertEquals(1,1);

    }
    @Test
        void buscarTodos(){
        //Mocks de la respuesta desde la BD
        given(clienteRepository.findAll())
                .willReturn(ClienteMocksTest.CLIENTES_LIST);

        //Llamado al servicio para validar
        List<ClienteDTO> clienteEsperados
                = clienteService.buscarTodos();

        //Verificacion del resultado
       assertEquals(2,clienteEsperados.size());
       assertEquals(ClienteMocksTest.DIRECCION_UNO,clienteEsperados.get(0).getDirecCliente());
    }
}
