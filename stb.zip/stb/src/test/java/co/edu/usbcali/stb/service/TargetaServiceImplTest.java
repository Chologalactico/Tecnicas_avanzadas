package co.edu.usbcali.stb.service;

import co.edu.usbcali.stb.mocks.TargetaMocksTest;
import co.edu.usbcali.stb.repository.TargetaRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.BDDAssumptions.given;

@SpringBootTest
public class TargetaServiceImplTest {
    @Mock
    private TargetaRepository targetaRepository;
    @InjectMocks
    private TargetaService targetaService;

    @Test
    void pruebaCorrecta(){
        Assertions.assertEquals(1,1);
    }

}
