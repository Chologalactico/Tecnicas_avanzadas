package co.edu.usbcali.stb.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SucursalServiceImplTest {
    @Test
    void pruebaCorrecta(){
        Assertions.assertEquals(1,1);
    }
}
