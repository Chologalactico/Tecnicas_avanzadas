package co.edu.usbcali.stb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StbApplicationTests {

	@Test
	void contextLoads() {
	}

}
