package co.edu.usbcali.stb.controller;
import co.edu.usbcali.stb.domain.Transaccion;
import co.edu.usbcali.stb.dto.TransaccionDTO;
import co.edu.usbcali.stb.mapper.TransaccionMapper;
import co.edu.usbcali.stb.repository.TransaccionRepository;
import co.edu.usbcali.stb.service.TransaccionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transaccion")
public class TransaccionController {

    private final TransaccionRepository transaccionrepository;
    private final TransaccionService transaccionService;

    public TransaccionController(TransaccionRepository transaccionrepository, TransaccionService transaccionService){
        this.transaccionrepository=transaccionrepository;
        this.transaccionService = transaccionService;
    }


    @GetMapping("/Validar")
    public String validarController(){
        return "Controlador Correcto";
    }


    @GetMapping("/ObtenerTodos")
    public List<Transaccion>obtenerTodos(){
        List<Transaccion>transaccion = transaccionrepository.findAll();
        return transaccion;
    }


    @GetMapping("/porId/{id}")
    public ResponseEntity<TransaccionDTO> buscarPorId(@PathVariable Integer id)throws Exception{
        Transaccion transaccion = transaccionrepository.getReferenceById(id);

        TransaccionDTO transaccionDTO = TransaccionMapper.domainToDto(transaccion);

        return  new ResponseEntity<>(transaccionDTO, HttpStatus.OK);
    }


    @PostMapping("/crear")
    public ResponseEntity<TransaccionDTO>guardarTransaccion(@RequestBody TransaccionDTO transaccionDTO)throws Exception{
        TransaccionDTO transaccionDTO1 = transaccionService.crearTransaccion(transaccionDTO);
        return new ResponseEntity<>(transaccionDTO1,HttpStatus.OK);
    }
    @PutMapping("/update")
    public ResponseEntity<TransaccionDTO>actualizarTransaccion(@RequestBody TransaccionDTO transaccionDTO)throws Exception{
        TransaccionDTO transaccionDTO1 = transaccionService.updateTransaccion(transaccionDTO);
        return new ResponseEntity<>(transaccionDTO1,HttpStatus.OK);
    }
    @DeleteMapping("/delete")
    public ResponseEntity<TransaccionDTO>eliminarTransaccion(@RequestBody TransaccionDTO transaccionDTO)throws Exception{
        TransaccionDTO transaccionDTO1 = transaccionService.deleteTransaccion(transaccionDTO);
        return new ResponseEntity<>(transaccionDTO1,HttpStatus.OK);
    }
}
