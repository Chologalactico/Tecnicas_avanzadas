package co.edu.usbcali.stb.service;
import co.edu.usbcali.stb.dto.CuentaDTO;
import co.edu.usbcali.stb.dto.TargetaDTO;

import java.util.List;

public interface TargetaService {

    public TargetaDTO createTargeta(TargetaDTO targetaDTO) throws Exception;
    public TargetaDTO updateTargeta(TargetaDTO targetaDTO) throws Exception;
    public TargetaDTO deleteTargeta(TargetaDTO targetaDTO) throws Exception;

    List<TargetaDTO> buscarTodos();
    TargetaDTO buscarPorId(Integer id)throws Exception;
}
