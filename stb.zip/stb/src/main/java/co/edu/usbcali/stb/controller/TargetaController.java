package co.edu.usbcali.stb.controller;

import co.edu.usbcali.stb.domain.Targeta;
import co.edu.usbcali.stb.dto.CuentaDTO;
import co.edu.usbcali.stb.dto.TargetaDTO;
import co.edu.usbcali.stb.mapper.TargetaMapper;
import co.edu.usbcali.stb.repository.TargetaRepository;
import co.edu.usbcali.stb.service.TargetaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/targeta")


public class TargetaController {
    private final TargetaRepository targetarepository;
    private  final TargetaService targetaService;

    public TargetaController(TargetaRepository targetarepository, TargetaService targetaService){
        this.targetarepository = targetarepository;
        this.targetaService = targetaService;
    }
    @GetMapping("/Validar")

    public String validarController(){
        return "Controlador Correcto";
    }


    @GetMapping("/ObtenerTodos")

    public List<TargetaDTO>obtenerTodos(){
        List<TargetaDTO> targetas = targetaService.buscarTodos();
        return targetas;
    }


    @GetMapping("/porId/{id}")

    public ResponseEntity<TargetaDTO> buscarPorId(@PathVariable Integer id)throws Exception{
        return  new ResponseEntity<>(targetaService.buscarPorId(id), HttpStatus.OK);
    }



    @PostMapping("/create")
    public ResponseEntity<TargetaDTO>guardarTargeta(@RequestBody TargetaDTO targetaDTO)throws Exception{
        TargetaDTO targetaDTO1  = targetaService.createTargeta(targetaDTO);

        return new ResponseEntity<>(targetaDTO1,HttpStatus.OK);
    }
    @PutMapping("/update")
    public ResponseEntity<TargetaDTO>actualizarTargeta(@RequestBody TargetaDTO targetaDTO)throws Exception{
        TargetaDTO targetaDTO1  = targetaService.updateTargeta(targetaDTO);

        return new ResponseEntity<>(targetaDTO1,HttpStatus.OK);
    }
    @DeleteMapping("/delete")
    public ResponseEntity<TargetaDTO>eliminarTargeta(@RequestBody TargetaDTO targetaDTO)throws Exception{
        TargetaDTO targetaDTO1  = targetaService.deleteTargeta(targetaDTO);

        return new ResponseEntity<>(targetaDTO1,HttpStatus.OK);
    }




}
