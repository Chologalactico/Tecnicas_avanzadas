package co.edu.usbcali.stb.service;

import co.edu.usbcali.stb.dto.ClienteCompletoDTO;
import co.edu.usbcali.stb.dto.ClienteDTO;

import java.util.List;

public interface ClienteService {
    ClienteDTO createCliente(ClienteDTO clienteDTO) throws Exception;

    ClienteDTO updateCliente(ClienteDTO clienteDTO) throws Exception;

    ClienteDTO deleteCliente(ClienteDTO clienteDTO) throws Exception;

     public ClienteCompletoDTO buscarDatosClientesYCuenta(Integer idcliente)throws Exception;
      List<ClienteDTO> buscarTodos();
      ClienteDTO buscarPorId(Integer id) throws Exception;
}
