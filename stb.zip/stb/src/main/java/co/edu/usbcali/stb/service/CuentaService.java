package co.edu.usbcali.stb.service;
import co.edu.usbcali.stb.dto.ClienteDTO;
import co.edu.usbcali.stb.dto.CuentaDTO;

import java.util.List;

public interface CuentaService {
   public CuentaDTO createCuenta(CuentaDTO cuentaDTO) throws Exception;
   public CuentaDTO updateCuenta(CuentaDTO cuentaDTO) throws Exception;
   public CuentaDTO deleteCuenta(CuentaDTO cuentaDTO) throws Exception;
   List<CuentaDTO> buscarPedidosDeUnCliente(Integer idCliente) throws Exception;

   default CuentaDTO buscarPorId(Integer id) throws Exception {
      return null;
   }

}
