package co.edu.usbcali.stb.service;
import co.edu.usbcali.stb.dto.TransaccionDTO;

public interface TransaccionService {

    public TransaccionDTO crearTransaccion(TransaccionDTO transaccionDTO) throws Exception;
    public TransaccionDTO updateTransaccion(TransaccionDTO transaccionDTO) throws Exception;
    public TransaccionDTO deleteTransaccion(TransaccionDTO transaccionDTO) throws Exception;

}
