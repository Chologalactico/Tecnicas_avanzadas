package co.edu.usbcali.stb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StbApplication {

	public static void main(String[] args) {
		SpringApplication.run(StbApplication.class, args);}
}
