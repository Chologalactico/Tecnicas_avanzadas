package co.edu.usbcali.stb.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ClienteCompletoDTO {
    private Integer idCliente;
    private String nomCliente;
    private String cedulaCliente;
    private String direcCliente;
    private List<CuentaDTO> cuentas;
    private List<SucursalDTO> sucursales;
}
