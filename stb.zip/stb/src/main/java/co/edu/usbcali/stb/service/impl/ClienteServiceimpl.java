package co.edu.usbcali.stb.service.impl;


import co.edu.usbcali.stb.domain.Cliente;
import co.edu.usbcali.stb.dto.ClienteCompletoDTO;
import co.edu.usbcali.stb.dto.ClienteDTO;
import co.edu.usbcali.stb.dto.CuentaDTO;
import co.edu.usbcali.stb.mapper.ClienteMapper;
import co.edu.usbcali.stb.repository.ClienteRepository;
import co.edu.usbcali.stb.service.ClienteService;
import co.edu.usbcali.stb.service.CuentaService;
import org.springframework.stereotype.Service;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Optional;

@Service
public class ClienteServiceimpl implements ClienteService{

    private  final ClienteRepository clienteRepository;
    private final CuentaService cuentaService;

    public ClienteServiceimpl(ClienteRepository clienteRepository, CuentaService cuentaService) {
        this.clienteRepository = clienteRepository;
        this.cuentaService = cuentaService;
    }


    // Crear

    @Override
    public ClienteDTO createCliente(ClienteDTO clienteDTO) throws Exception {
        //1 Validar los datos de la categoria
        if  (clienteDTO == null){
            throw new Exception("La categoria es nula ");
        }
        if  (clienteDTO.getNomCliente() == null || clienteDTO.getNomCliente().isBlank()){
            throw new Exception("Nombre vacio");
        }
        if  (clienteDTO.getCedulaCliente() == null || clienteDTO.getCedulaCliente().isBlank()){
            throw new Exception("Cedula vacio");
        }
        if  (clienteDTO.getDirecCliente() == null || clienteDTO.getDirecCliente().isBlank()){
            throw new Exception("Direccion vacio");
        }

//VALIDACIONES
        //Validar que no exista una cliente con ese nombre
        Optional<Cliente> clientePorNombre = clienteRepository.findClienteByNomCliente(clienteDTO.getNomCliente());
        if(clientePorNombre.isPresent() ){
            throw new Exception(String.format("El cliente con el nombre ya se encuentra registrado",
                    clienteDTO.getNomCliente()));
        }

        //Validar que no existe una cliente con esa cedula
        Optional<Cliente> clientePorCedula = clienteRepository.findClienteByCedulaCliente(clienteDTO.getCedulaCliente());
        if(clientePorCedula.isPresent() ){
            throw new Exception(String.format("El cliente con la  cedula ya se encuentra registrada.",
                    clienteDTO.getCedulaCliente()));
        }



        //2 Registrar la categoria en db Mapeando desde el DTO hacia el domain
        Cliente cliente= ClienteMapper.dtoToDomain(clienteDTO);
        cliente = clienteRepository.save(cliente);
        //3 Retornar la mapeando el DTO
        clienteDTO = ClienteMapper.domainToDto(cliente);
        return clienteDTO;
    }


    //Actualizar
    public ClienteDTO updateCliente(ClienteDTO clienteDTO) throws Exception {
        // 1. Validar los datos del cliente a actualizar
        //1 Validar los datos de la categoria
        if  (clienteDTO == null){
            throw new Exception("La categoria es nula ");
        }
        if  (clienteDTO.getNomCliente() == null || clienteDTO.getNomCliente().isBlank()){
            throw new Exception("Nombre vacio");
        }
        if  (clienteDTO.getCedulaCliente() == null || clienteDTO.getCedulaCliente().isBlank()){
            throw new Exception("Cedula vacio");
        }
        if  (clienteDTO.getDirecCliente() == null || clienteDTO.getDirecCliente().isBlank()){
            throw new Exception("Direccion vacio");
        }

//VALIDACIONES
        //Validar que no exista una cliente con ese nombre
        Optional<Cliente> clientePorNombre = clienteRepository.findClienteByNomCliente(clienteDTO.getNomCliente());
        if(clientePorNombre.isPresent() ){
            throw new Exception(String.format("El cliente con el nombre ya se encuentra registrado",
                    clienteDTO.getNomCliente()));
        }

        //Validar que no existe una cliente con esa cedula
        Optional<Cliente> clientePorCedula = clienteRepository.findClienteByCedulaCliente(clienteDTO.getCedulaCliente());
        if(clientePorCedula.isPresent() ){
            throw new Exception(String.format("El cliente con la  cedula ya se encuentra registrada.",
                    clienteDTO.getCedulaCliente()));
        }



        //2 Registrar la categoria en db Mapeando desde el DTO hacia el domain
        Cliente cliente= ClienteMapper.dtoToDomain(clienteDTO);
        cliente = clienteRepository.save(cliente);
        //3 Retornar la mapeando el DTO
        clienteDTO = ClienteMapper.domainToDto(cliente);
        return clienteDTO;
    }


    //Eliminar
    public ClienteDTO deleteCliente(ClienteDTO clienteDTO) throws Exception {
            // 1. Obtener todos los clientes de la base de datos
            List<Cliente> clientes = clienteRepository.findAll();

            // 2. Verificar si hay clientes para listar
            if (clientes.isEmpty()) {
                // Puedes lanzar una excepción o devolver una lista vacía, según tus requisitos
                throw new RuntimeException("No hay clientes para listar");
            }

            // 3. Convertir la lista de entidades de Cliente a una lista de DTOs de Cliente
            List<ClienteDTO> clienteDTOs = clientes.stream()
                    .map(ClienteMapper::domainToDto)
                    .collect(Collectors.toList());

            // 4. Retornar la lista de DTOs de clientes
            return (ClienteDTO) clienteDTOs;

    }

    @Override
    public ClienteCompletoDTO buscarDatosClientesYCuenta(Integer idcliente) throws Exception {
        if(idcliente == null || idcliente.equals(0))
        {
            throw new Exception("Id del cliente no valido");
        }
        Cliente cliente = clienteRepository.getReferenceById(idcliente);
        List<CuentaDTO> cuentas = cuentaService.buscarPedidosDeUnCliente(idcliente);

        return ClienteMapper.domainToClienteCompleto(cliente, cuentas);
    }

    @Override
    public List<ClienteDTO> buscarTodos() {
        return ClienteMapper.domainToDtoList(clienteRepository.findAll());
    }

    @Override
    public ClienteDTO buscarPorId(Integer idCliente) throws Exception {
        if(idCliente == null || idCliente.equals(0)){
            throw new Exception(("Id no valido"));
        }
        return ClienteMapper.domainToDto(clienteRepository.getReferenceById(idCliente));
    }


}

