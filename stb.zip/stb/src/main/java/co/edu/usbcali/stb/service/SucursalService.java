package co.edu.usbcali.stb.service;

import co.edu.usbcali.stb.dto.SucursalDTO;

public interface SucursalService {

    public SucursalDTO createSucursal(SucursalDTO sucursalDTO) throws Exception;
    public SucursalDTO updateSucursal(SucursalDTO sucursalDTO) throws Exception;
    public SucursalDTO deleteSucursal(SucursalDTO sucursalDTO) throws Exception;

}
