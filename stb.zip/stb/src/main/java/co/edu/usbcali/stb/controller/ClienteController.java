package co.edu.usbcali.stb.controller;

import co.edu.usbcali.stb.domain.Cliente;
import co.edu.usbcali.stb.dto.ClienteCompletoDTO;
import co.edu.usbcali.stb.dto.ClienteDTO;
import co.edu.usbcali.stb.mapper.ClienteMapper;
import co.edu.usbcali.stb.service.ClienteService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/cliente")
public class ClienteController {
    private final ClienteService clienteService;

    public ClienteController(ClienteService clienteService ){
        this.clienteService = clienteService;

    }
    @GetMapping("/Validar")
    public String validarController(){
        return "Controlador Correcto";
    }

    @GetMapping("/ObtenerTodos")
    public List<ClienteDTO> obtenerTodos(){
        List<ClienteDTO> clientes = clienteService.buscarTodos();
        return clientes;
    }
    @GetMapping("/porId/{id}")
    public ResponseEntity<ClienteDTO>buscarPorId(@PathVariable Integer id)throws Exception{
        return  new ResponseEntity<>(clienteService.buscarPorId(id), HttpStatus.OK);
    }
    @PostMapping("/create")
    public ResponseEntity<ClienteDTO>guardarCliente(@RequestBody ClienteDTO clienteDTO)throws Exception{
        ClienteDTO clienteDTO1 = clienteService.createCliente(clienteDTO);
        return new ResponseEntity<>(clienteDTO1,HttpStatus.OK);
    }
    @PostMapping("/update")
    public ResponseEntity<?>actualizarCliente(@RequestBody ClienteDTO clienteDTO)throws Exception{
        ClienteDTO clienteDTO1 = clienteService.updateCliente(clienteDTO);
        return new ResponseEntity<>(clienteDTO1,HttpStatus.OK);
    }
    @PostMapping("/delete")
    public ResponseEntity<?>eliminarCliente(@RequestBody ClienteDTO clienteDTO)throws Exception{
        ClienteDTO clienteDTO1 = clienteService.deleteCliente(clienteDTO);
        return new ResponseEntity<>(clienteDTO1,HttpStatus.OK);
    }
    @PostMapping("/buscarDatosdeClienteYcuenta/{idCliente}")
    public ResponseEntity<ClienteCompletoDTO>buscarDatosClientesYCuenta(Integer idCliente) {

        try{
            return new ResponseEntity<>(clienteService.buscarDatosClientesYCuenta(idCliente)
            ,HttpStatus.OK);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
}
