package co.edu.usbcali.stb.repository;

import co.edu.usbcali.stb.domain.Cuenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CuentaRepository extends JpaRepository<Cuenta,Integer>{


    Optional<Cuenta> findCuentaByNumCuenta(String numCuenta);
    List<Cuenta> findCuentaByClienteIdCliente (Integer idcliente);
}
